// src/controllers/processingController.js
"use strict";

const path = require("path");
const fs = require("fs");
const { v4: uuidv4 } = require("uuid");

const audioService = require("../services/audioService");
const { streamZipOfFiles } = require("../utils/zipHelper");
const jobStore = require("../services/jobStoreFile");

/**
 * POST /api/v1/process
 * Requires: Authorization: Bearer <token>, multipart/form-data with 'file'
 * - Transcodes the uploaded file into multiple variants
 * - Persists a job record
 * - Streams a ZIP of all variants back to the client
 */
exports.processFile = async (req, res, next) => {
  try {
    if (!req.file) {
      return res
        .status(400)
        .json({ error: { code: "INVALID_INPUT", message: "file is required" } });
    }

    const ownerId = req.user.id; // from auth middleware
    const jobId = uuidv4();
    console.log("[PROCESS] jobId:", jobId);

    // Work directory for this job
    const workDir = path.join(process.cwd(), "storage", "tmp", jobId);
    fs.mkdirSync(workDir, { recursive: true });

    const uploadedPath = req.file.path;
    const originalBase = path
      .parse(req.file.originalname)
      .name.replace(/\s+/g, "_");

    const startedAt = new Date();

    // Transcode to multiple variants (your service should return:
    // [{ filePath: <abs path>, name: <nice filename> }, ...])
    const outputs = await audioService.transcodeVariants({
      inputPath: uploadedPath,
      baseName: originalBase,
      workDir,
    });

    // Debug: verify on-disk presence/sizes
    try {
      for (const o of outputs) {
        try {
          const s = fs.statSync(o.filePath);
          console.log("[ZIP CHECK]", o.name, "size:", s.size, "bytes");
        } catch (e) {
          console.warn("[ZIP CHECK] missing:", o?.filePath, e.message);
        }
      }
    } catch (e) {
      console.warn("[ZIP CHECK] unexpected check error:", e.message);
    }

    const finishedAt = new Date();

    // Persist job metadata (don’t leak absolute paths to clients except when downloading)
    const jobRecord = {
      id: jobId,
      ownerId,
      originalName: req.file.originalname,
      baseName: originalBase,
      uploadedPath,
      outputs, // keep absolute filePath here for internal use
      startedAt,
      finishedAt,
      status: "done",
      processingMs: finishedAt - startedAt,
    };
    await jobStore.add(jobRecord);

    // Expose the job id (useful for GET calls later)
    res.setHeader("X-Job-Id", jobId);

    // Stream a ZIP of outputs back to the client
    const zipName = `compressed_${originalBase}.zip`;
    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", `attachment; filename="${zipName}"`);
    res.setHeader("Cache-Control", "no-store");

    await streamZipOfFiles(res, outputs);

    // NOTE: if you plan to keep files for later downloads, don't clean up here.
    // Use a separate cleanup process/cron instead.
  } catch (err) {
    next(err);
  }
};

/**
 * GET /api/v1/history?page=&limit=&from=&to=
 * Returns paginated job list for the authenticated user (newest first)
 */
exports.history = async (req, res, next) => {
  try {
    const page = Math.max(parseInt(req.query.page || "1", 10), 1);
    const limit = Math.min(Math.max(parseInt(req.query.limit || "10", 10), 1), 100);
    const { from, to } = req.query;

    const items = await jobStore.findByOwner(req.user.id, { from, to });
    const total = items.length;

    const start = (page - 1) * limit;
    const slice = items.slice(start, start + limit);

    const mapped = slice.map((j) => ({
      id: j.id,
      originalName: j.originalName,
      startedAt: j.startedAt,
      finishedAt: j.finishedAt,
      status: j.status || "done",
      processingMs:
        j.processingMs ?? (new Date(j.finishedAt) - new Date(j.startedAt)),
      outputs: j.outputs.map((o) => ({ name: o.name })), // don’t leak absolute paths
      downloadUrl: `/api/v1/results/${j.id}/download`,       // single variant (default first)
      downloadAllUrl: `/api/v1/results/${j.id}/download-all` // zip of all variants
    }));

    res.json({
      page,
      limit,
      total,
      count: mapped.length,
      items: mapped,
    });
  } catch (err) {
    next(err);
  }
};

/**
 * GET /api/v1/results/:id
 * Returns structured metadata about a specific job
 */
exports.getResult = async (req, res, next) => {
  try {
    const job = await jobStore.findById(req.params.id);
    if (!job) {
      return res
        .status(404)
        .json({ error: { code: "NOT_FOUND", message: "job not found" } });
    }

    // Ownership check (allow admin override if you add that policy)
    if (job.ownerId !== req.user.id && req.user.role !== "admin") {
      return res
        .status(403)
        .json({ error: { code: "FORBIDDEN", message: "not your file" } });
    }

    const payload = {
      id: job.id,
      ownerId: job.ownerId,
      originalName: job.originalName,
      baseName: job.baseName,
      status: job.status || "done",
      startedAt: job.startedAt,
      finishedAt: job.finishedAt,
      processingMs:
        job.processingMs ?? (new Date(job.finishedAt) - new Date(job.startedAt)),
      outputs: job.outputs.map((o, idx) => {
        // infer variant label (optional)
        let variant = "UNKNOWN";
        if (/_HQ_/i.test(o.name)) variant = "HQ";
        else if (/_MQ_/i.test(o.name)) variant = "MQ";
        else if (/_LQ_/i.test(o.name)) variant = "LQ";

        return {
          index: idx,
          variant,
          name: o.name,
          downloadUrl: `/api/v1/results/${job.id}/download?variant=${variant}`,
        };
      }),
      downloadAllUrl: `/api/v1/results/${job.id}/download-all`,
    };

    res.json(payload);
  } catch (err) {
    next(err);
  }
};

/**
 * GET /api/v1/results/:id/download?variant=HQ|MQ|LQ
 * Streams a single variant (default: first output) back to the client
 */
exports.downloadResult = async (req, res, next) => {
  try {
    const job = await jobStore.findById(req.params.id);
    if (!job) {
      return res
        .status(404)
        .json({ error: { code: "NOT_FOUND", message: "job not found" } });
    }

    if (job.ownerId !== req.user.id && req.user.role !== "admin") {
      return res
        .status(403)
        .json({ error: { code: "FORBIDDEN", message: "not your file" } });
    }

    const requested = (req.query.variant || "").toUpperCase();
    let file = job.outputs[0]; // default to first output

    if (requested === "HQ") {
      file = job.outputs.find((o) => /_HQ_/i.test(o.name)) || file;
    } else if (requested === "MQ") {
      file = job.outputs.find((o) => /_MQ_/i.test(o.name)) || file;
    } else if (requested === "LQ") {
      file = job.outputs.find((o) => /_LQ_/i.test(o.name)) || file;
    }

    if (!file || !fs.existsSync(file.filePath)) {
      return res
        .status(410) // Gone
        .json({ error: { code: "FILE_GONE", message: "output file not found" } });
    }

    // Debug: confirm we’re sending a real file with bytes
    try {
      const st = fs.statSync(file.filePath);
      console.log("[DL] sending", file.name, "size:", st.size, "path:", file.filePath);
    } catch (e) {
      console.warn("[DL] stat failed:", file?.filePath, e.message);
    }

    return res.download(file.filePath, file.name);
  } catch (err) {
    next(err);
  }
};

/**
 * GET /api/v1/results/:id/download-all
 * Streams a ZIP containing ALL existing variant files for that job.
 */
exports.downloadAllResults = async (req, res, next) => {
  try {
    const job = await jobStore.findById(req.params.id);
    if (!job) {
      return res
        .status(404)
        .json({ error: { code: "NOT_FOUND", message: "job not found" } });
    }

    if (job.ownerId !== req.user.id && req.user.role !== "admin") {
      return res
        .status(403)
        .json({ error: { code: "FORBIDDEN", message: "not your file" } });
    }

    // Filter to files that still exist on disk
    const existing = (job.outputs || []).filter(
      (o) => o?.filePath && fs.existsSync(o.filePath)
    );

    if (existing.length === 0) {
      return res
        .status(409)
        .json({ error: { code: "NOT_READY", message: "No output files available" } });
    }

    const zipName = `results_${job.id}.zip`;
    res.setHeader("Content-Type", "application/zip");
    res.setHeader("Content-Disposition", `attachment; filename="${zipName}"`);
    res.setHeader("Cache-Control", "no-store");

    // Reuse your helper that zips an array of files [{ filePath, name }]
    await streamZipOfFiles(res, existing);
  } catch (err) {
    next(err);
  }
};

